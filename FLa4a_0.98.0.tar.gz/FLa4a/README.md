FLa4a
=====

FLR package of a4a assessment model

Currently under development using roxygen2!