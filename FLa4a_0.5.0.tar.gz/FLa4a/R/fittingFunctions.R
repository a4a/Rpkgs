


#' The user interface to the a4a fitting routine.
#'
#'
#' @param fmodel a formula object depicting the model for log fishing mortality at age
#' @param qmodel a list of formula objects depicting the models for log survey catchability at age
#' @param rmodel a formula object depicting the model for log recruitment
#' @param stock an FLStock object containing catch and stock information
#' @param indices an FLIndices object containing survey indices 
#' @param fmodel.extra a named list of expressions used to add covariates to the model for log fishing mortality at age
#' @param qmodel.extra a named list of expressions used to add covariates the models for log survey catchability at age
#' @param wkdir used to set a working directory for the admb optimiser.  If wkdir is set all admb files are saved to this folder otherwise they are deleted.
#' @param verbose if true admb fitting information is printed to the screen
#' @return an FLa4aFit object
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @author Ernesto Jardim \email{ernesto.jardim@@jrc.ec.europa.eu}
#' @export
#' @examples
#' data(ple4)
#' data(ple4.indices)
#' # define sub models
#' fmodel <- ~ s(age, k=4) + factor(year)
#' qmodel <- list(~ s(age, k=4), ~ s(age, k=4))
#' fit <- a4aFit(fmodel, qmodel, stock = ple4, indices = ple4.indices[1:2], verbose = FALSE)
#' fit
#'
#'data(hakeGSA7)
#'data(hakeGSA7.idx)
#'
#'stk <- hakeGSA7
#'idx <- hakeGSA7.idx
#'
#'fit1 <- a4aFit(~ s(age, k=3) + 1, list(~ s(age, k=3)), stock = stk, indices = idx)
#'fit2 <- a4aFit(~ s(age, k=3) + year, list(~ s(age, k=3)), stock = stk, indices = idx)
#'fit3 <- a4aFit(~ s(age, k=3) + factor(year), list(~ s(age, k=3)), stock = stk, indices = idx)
#'fit4 <- a4aFit(~ s(age, k=3) + s(year, k = 3), list(~ s(age, k=3)), stock = stk, indices = idx)
#'fit5 <- a4aFit(~ s(age, k=3) + s(year, k = 4), list(~ s(age, k=3)), stock = stk, indices = idx)
#'fit6 <- a4aFit(~ s(age, k=3) + s(year, k = 5), list(~ s(age, k=3)), stock = stk, indices = idx)
#'fit7 <- a4aFit(~ s(age, k=3) + s(year, k = 6), list(~ s(age, k=3)), stock = stk, indices = idx)
#'fit8 <- a4aFit(~ s(age, k=3) + s(year, k = 7), list(~ s(age, k=3)), stock = stk, indices = idx)
#'fit9 <- a4aFit(~ s(age, k=3) + s(year, k = 8), list(~ s(age, k=3)), stock = stk, indices = idx)
#'
#'aics <- AIC(fit1, fit2, fit3, fit4, fit5, fit6, fit7, fit8, fit9)
#'aics[order(aics $ AIC),]
#'best <- get(rownames(aics)[which.min(aics $ AIC)])
#'aics
#'best
#'
#'image(Matrix(vcov(best)))
a4a <- function(fmodel, qmodel, rmodel = ~ factor(year), 
                stock, indices, srrCV = -1,
                fmodel.extra = NULL, qmodel.extra = NULL, rmodel.extra = NULL,
                vmodel = NULL, vmodel.extra = NULL,
                wkdir = NULL, verbose = FALSE, MCMC = FALSE, NMCMC = 1000)
{
  
  # first some checks
  if (any(is.infinite(log(catch.n(stock))))) stop("only non-zero catches allowed.")
  if (any(is.infinite(log( unlist(lapply(indices, function(x) c(index(x)))) ))))  stop("only non-zero survey indices allowed.")
   
  # put default settings in argument list
  randomF <- 0  
  randomQ <- 0

  # although unused, need to specify the random models for F and Q for now
  fprior <- "iid"
  ftau <- 0.05
  nsurv <- length (indices)
  qprior <- rep("iid", nsurv)
  qtau <- rep(0.01, nsurv)

  
  # add data to argument list
  basedata <- c(list(catch=catch.n(stock)[drop=TRUE]),
                     lapply(indices, function(x) index(x)[drop=TRUE] ))
                     
  # centering on log scale
  center.log <- sapply(basedata, function(x) mean(log(x), na.rm = TRUE))

  natMor <-        m(stock)[drop=TRUE]
  mat    <-      mat(stock)[drop=TRUE]
  sWt    <- stock.wt(stock)[drop=TRUE]
  cWt    <- catch.wt(stock)[drop=TRUE]

  # other arguments
  surveytime <- unname(sapply(indices, function(x) mean(c(dims(x) $ startf, dims(x) $ endf))))
  fbar <-  unname(range(stock)[c("minfbar","maxfbar")])
  plusgroup <- as.integer( !is.na(range(stock)["plusgroup"]), range(stock)["plusgroup"] >= range(stock)["max"] )

  # variance model default - 1 var for each survey
  if (is.null(vmodel)) vmodel <- lapply(1:length(basedata), function(i) ~ 1)

  # Create the directory where to store model config, data and results files
  if (is.null(wkdir)) keep <- FALSE else keep <- TRUE 
  if (keep) {
    # create the directory locally - whereever specified by the user
    wkdir.start <- wkdir

    # if this directory already exists, try the numbered versions
    kk <- 1
    ans <- file.exists(wkdir)
    while(ans) {
      wkdir <- paste(wkdir.start,"-", kk, sep = "")
      kk <- kk + 1
      ans <- file.exists(wkdir)
    }
    # if several a4aFit()'s are run in parallel, we might have a
    # conflict. if so, create a random name
    if (file.exists(wkdir)) {
      wkdir <- paste(wkdir, "-", substring(as.character(runif(1)), 3), sep = "")
    }
    cat("Model and results are stored in working directory [", wkdir,"]\n", sep = "")
  } else {
    # no wkdir specified by user so create a temporary directory
    wkdir <- tempfile('file', tempdir())
  }
    
  # Create a directory where to store data and results
  # TODO check if wkdir exists
  dir.create(wkdir, showWarnings = FALSE)
 
 
  # process recruitment formula for specials
  #tf <- terms.formula(rmodel, specials = "bevholt")
  #if (!is.null(attr(tf, "specials"))) {
  #  srrCV <- 
  #} else {
  #  srrCV <- -1 # turn off SR relationship
  #}

 
  # run setup functions
  # write data
  toADMB(basedata, center.log, natMor, mat, cWt, sWt, wkdir)
  # write config files TODO improve interface with executable
  setupMain(surveytime, fbar, plusgroup, srrCV, randomF, randomQ, basedata, wkdir)
  # make sure contrasts are set to sumto zero for better performance
  opts <- options(contrasts = c(unordered = "contr.sum", ordered = "contr.poly")) 
  setupF(fmodel, basedata, fmodel.extra, wkdir)
  setupQ(qmodel, basedata, qmodel.extra, wkdir)
  setupR(rmodel, basedata, rmodel.extra, wkdir)
  setupV(vmodel, basedata, vmodel.extra, wkdir)

  setupFprior(fprior, tau = ftau, basedata, wkdir)
  setupQprior(qprior, tau = qtau, basedata, wkdir)

  options(opts) # reset options

  # arguments
  args <- character(0)
  if (MCMC) args <- c(args, paste0("-mcmc ",floor(NMCMC) * 10," -mcsave 10"))
  args <- paste(args, collapse = " ")
  
  # run executable in wkdir directory
  if (os.type("linux")) {
    if (verbose) {
      echoc <- system(paste0("cd ", shQuote(wkdir), ";a4a ", args))
    } else {
      echoc <- system(paste0("cd ", shQuote(wkdir), ";a4a ", args, " > logfile.txt"))
    }
  } else if (os.type("windows")) {
    if (verbose) {
      echoc <- shell(paste0("cd /D", shQuote(wkdir), " & a4a"))
    } else {
      echoc <- shell(paste0("cd /D", shQuote(wkdir), " & a4a > logfile.txt"))
    }
  }
  if (echoc != 0) stop("Bad return from a4a executable: probably solution is not unique, try reducing parameters.\n")

  if (MCMC) {
  # read admb output from file
  
    filen <- file(paste0(wkdir, '/a4a.psv'), "rb")
    nopar <- readBin(filen, what = integer(), n = 1)
    mcmc <- readBin(filen, what = numeric(), n = nopar * 10000)
    close(filen)
    mcmc <- matrix(mcmc, byrow = TRUE, ncol = nopar)
    #colnames(mcmc) <-     
    return(mcmc)

  } # else 
  # read admb output from file
  fit   <- read.fit(paste0(wkdir, '/a4a'))

  fit$N <- as.matrix(read.table(paste0(wkdir, '/n.out'), header = FALSE))
  fit$F <- as.matrix(read.table(paste0(wkdir, '/f.out'), header = FALSE))
  
  colnames(fit$N) <- colnames(fit$F) <- sort(unique(fit$res$age))
  rownames(fit$N) <- rownames(fit$F) <- sort(unique(fit$res$year))

  readQ <- function(i) {
    ret <- read.table(paste0(wkdir, '/q.out'), header = FALSE, 
                     skip = c(0, cumsum(noQyears))[i],
                     nrows = noQyears[i])
    ret <- as.matrix(ret)
    rownames(ret) <- sort(unique(fit $ res $ year[fit $ res $ fleet == i + 1]))
    colnames(ret) <- sort(unique(fit $ res $ age[fit $ res $ fleet == i + 1]))
    ret
  }
  noQyears <- rowSums(table(fit $ res $ fleet, fit $ res $ year)[-1, , drop = FALSE] > 0)
  fit$logQ <- lapply(1:length(noQyears), readQ)

  # remove temporary directory - keep only true when dir is not temp dir
  if (!keep) unlink(wkdir)


  # convert fit into FLa4aFit class
  ind.names <- names(indices) #paste("survey", 1:length(fit $ logQ))

  stk.n <- t(fit $ N)
  names(dimnames(stk.n)) <- c("age","year")

  hvst <- t(fit $ F)
  names(dimnames(hvst)) <- c("age","year")

  logq <- lapply(fit $ logQ, function(x) {x <- t(x); names(dimnames(x)) <- c("age","year"); FLQuant(x)})
 
  names(logq) <- ind.names
  
  getres <- function(x, what, .fleet) {
    x <- cbind(subset(fit $ res, fleet == .fleet)[c(what,"age", "year")], unit = "unique", season = "all", area = "unique", iter = 1)
    names(x)[1] <- "data"
    as.FLQuant(x)
  }
  getres2 <- function(x, what) {
    x <- lapply(sort(unique(x$fleet))[-1], function(fleet) getres(x, what, fleet))
    names(x) <- ind.names
    do.call(FLQuants, x)
  }


  # fill up an a4aFit object

  out <- new("a4aFitSA")
  
  # First the a4aFit bits
  out @ name <- stock @ name
  out @ desc <- stock @ desc
  out @ range <- stock @ range
  out @ stock.n <- FLQuant(stk.n) * exp(center.log[1])
  out @ harvest <- FLQuant(hvst, units = "f")
  out @ catch.n <- exp(getres(fit $ res, "obs", 1)) * exp(center.log[1])
  out @ index <- lapply(getres2(fit $ res, "obs"), exp)
  
  # now the a4aFitSA bits
  out @ call <- as.character(match.call())
  out @ fitSumm <- with(fit, c(nopar = nopar, nlogl = nlogl, maxgrad = maxgrad, 
                               npar = npar, logDetHess = logDetHess, 
                               nobs = sum(!is.na(unlist(basedata)))   ))
  out @ pars <- new("SCAPars")
  
  out @ pars @ fmodel @ model <- fmodel
  out @ pars @ qmodel <- as(lapply(qmodel, function(form) new("submodel", model = form)), "submodels")
  out @ pars @ rmodel @ model <- rmodel  
  out @ pars @ n1model @ model <- ~ factor(age) # doesn't change
  
#  out @ index.name <- ind.names
#  out @ logq <- do.call(FLQuants, logq)

#  out @ catch.lvar <- getres(fit $ res, "sd", 1)^2 
#  out @ catch.lhat <- getres(fit $ res, "pred", 1) + center.log[1]
#  out @ catch.lres <- getres(fit $ res, "res", 1) 

#  out @ index <- lapply(getres2(fit $ res, "obs"), exp)
#  out @ index.lvar <- lapply(getres2(fit $ res, "sd"), "^", 2) 
#  out @ index.lhat <- getres2(fit $ res, "pred")
#  out @ index.lres <- getres2(fit $ res, "res") 
  
#  for (i in 1:length(out @ index)) {
#    out @ index[[i]]     <- out @ index[[i]] * exp(center.log[i+1])
#    out @ index.lhat[[i]] <- out @ index.lhat[[i]] + center.log[i+1]
#    out @ logq[[i]] <- out @ logq[[i]] + center.log[i+1] - center.log[1]
#  }  
  
#  out @ logQ <- out @ index
#  for (i in 1:length(out @ logQ)) out @ logQ[[i]] @ .Data <- fit $ logQ[[i]]


#  out @ coefficients <- fit $ est
#  out @ covariance <- fit $ cov
#  names(out @ coefficients) <- fit $ names
#  colnames(out @ covariance) <- rownames(out @ covariance) <- fit $ names

  # add some extra bits and pieces


  out
}


#' Extracts the ADMB output from the standard ADMB output files given a directory
#'
#'
#' @param file an FLStock object containing catch and stock information
#' @return a list containing the summary of the ADMB optimisation
#' @note \code{read.fit} is intended to be used internally
#' @author Anders Nielsen \email{an@@aqua.dtu.dk}
#' @export
read.fit<-function(file) {
  #
  #Function to read a basic AD Model Builder fit.
  #
  #Use for instance by:
  #
  #simple.fit <- read.fit('c:/admb/examples/simple')
  #
  #Then the object 'simple.fit' is a list containing sub-objects
  # 'names', 'est', 'std', 'cor', and 'cov' for all model
  # parameters and sdreport quantities.
  #
  ret <- list()
  ret$res <- read.table(paste(file, '.res', sep = ''), header = TRUE)
  parfile <- as.numeric(scan(paste(file, '.par', sep=''), what='', n=16, quiet = TRUE)[c(6,11,16)])
  ret$nopar <- as.integer(parfile[1])
  ret$nlogl <- parfile[2]
  ret$maxgrad <- parfile[3]
  file <- paste(file, '.cor', sep = '')
  lin <- readLines(file)
  ret$npar <- length(lin) - 2
  ret$logDetHess <- as.numeric(strsplit(lin[1], '=')[[1]][2])
  sublin <- lapply(strsplit(lin[1:ret$npar+2], ' '),function(x)x[x!=''])
  ret$names <- unlist(lapply(sublin,function(x)x[2]))
  ret$est <- as.numeric(unlist(lapply(sublin,function(x)x[3])))
  ret$std <- as.numeric(unlist(lapply(sublin,function(x)x[4])))
  ret$cor <- matrix(NA, ret$npar, ret$npar)
  corvec <- unlist(sapply(1:length(sublin), function(i)sublin[[i]][5:(4+i)]))
  ret$cor[upper.tri(ret$cor, diag=TRUE)] <- as.numeric(corvec)
  ret$cor[lower.tri(ret$cor)] <- t(ret$cor)[lower.tri(ret$cor)]
  ret$cov <- ret$cor*(ret$std%o%ret$std)

  ret
}


