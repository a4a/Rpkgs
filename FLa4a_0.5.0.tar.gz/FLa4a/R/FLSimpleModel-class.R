#====================================================================
# FLSimpleModel
#====================================================================

# validity: iters 1 or n; names of params in formula; only 2 dim pars

setClass("FLSimpleModel",
        representation(
                model = "formula",
                params = "FLPar",
				vcov = "array",
				distr = "character"),
        prototype = prototype(
                model = ~a,
                params = FLPar(a=1),
				vcov = new("array"),
				distr = "norm")
)

# constructor

setGeneric("FLSimpleModel", function(object, ...)
	standardGeneric("FLSimpleModel"))

setMethod("FLSimpleModel", signature(object="missing"),
  function(...) {
    # empty
  	if(missing(...)){
	  	new("FLSimpleModel")
    # or not
  	} else {
      args <- list(...)
	  args$Class <- 'FLSimpleModel'
      do.call("new", args)
	  }
  }
)

# accessors

#setMethod("call", "a4aFitSA", function(object) object@call)

#setGeneric("model", function(object, ...) standardGeneric("model"))
#setMethod("model", "FLSimpleModel", function(object) object@model)

#setGeneric("model<-", function(object, ...) standardGeneric("model<-"))
#setReplaceMethod("model", "FLSimpleModel", function(object, value) object@model <- value)

#setMethod("params", "FLSimpleModel", function(object) object@params)
#setReplaceMethod("params", "FLSimpleModel", function(object, value) object@params <- value)

#setMethod("vcov", "FLSimpleModel", function(object) object@vcov)
#setReplaceMethod("vcov", "FLSimpleModel", function(object, value) object@vcov <- value)

#setMethod("distr", "FLSimpleModel", function(object) object@distr)
#setGeneric("distr<-", function(object, ...) standardGeneric("distr<-"))
#setReplaceMethod("distr", "FLSimpleModel", function(object, value) object@distr <- value)

# mvrnorm
#setGeneric("mvrnorm", function(object, ...) standardGeneric("mvrnorm"))
setMethod("mvrnorm", c("numeric", "FLSimpleModel", "missing", "missing", "missing", "missing"), function(n, mu){
	object <- mu
	mu <- iterMedians(params(object))
	dm <- dim(mu)
	dnm <- dimnames(mu)
	Sigma = apply(vcov(object),c(1,2),median)
	res <- do.call("mvrnorm", list(mu=c(mu), Sigma=Sigma, n=n))
	if(n>1)	res <- t(res) else res <- matrix(res, ncol=1)
	dnm$iter <- 1:n
	dimnames(res) <- dnm
	res <- FLPar(res)
	units(res) <- units(mu)
	FLSimpleModel(model=model(object), params=res)
})

setMethod("mvrnorm", c("FLSimpleModel", "missing", "missing", "missing", "missing", "missing"), function(n){
	object <- n	
	mu <- params(object)
	dm <- dim(mu)
	dnm <- dimnames(mu)
	Sigma = vcov(object)
	if(dm[2]>1){
		res <- array(NA, dim=dm, dimnames=dnm)
		for(i in 1:dm[2]) res[,i] <- do.call("mvrnorm", list(mu=mu[,i], Sigma=Sigma[,,i]))
		res <- FLPar(res)
		units(res) <- units(mu)
		res <- FLSimpleModel(model=model(object), params=res)
	} else {
		res <- mvrnorm(1,object)
	}
	res
})

## example mvrnorm
#m1 <- FLSimpleModel(model=~k^0.66*t^0.57, params=FLPar(matrix(c(0.4,10,0.5,11), ncol=2, dimnames=list(params=c("k","t"), iter=1:2))), vcov=array(c(0.04, 0.05,0.05, 1), dim=c(2,2,2)))

#m2 <- FLSimpleModel(model=~k^0.66*t^0.57, params=FLPar(k=0.4, t=10), vcov=array(c(0.04, 0.05,0.05, 1), dim=c(2,2)))

#m1r <- mvrnorm(m1)
#m1rb <- mvrnorm(10, m1)
#m2r <- mvrnorm(m2)
#m2rb <- mvrnorm(10, m2)

# predict
setMethod("predict", "FLSimpleModel", function(object, ...){
	args <- list(...)
	pr <- params(object)
	res <- apply(pr,2,function(x){
		lst <- as.list(x)
		eval(as.list(model(object))[[2]], envir=c(args, lst))
	})
	res <- matrix(res, ncol=dim(pr)[2])
	dimnames(res) <- list(pred=1:nrow(res), iter=1:dim(pr)[2])
	res
})

## example
#mod1 <- FLSimpleModel(model=~exp(-age-0.5), params=FLPar(a=NA))
#mod2 <- FLSimpleModel(model=~1.5*k, params=FLPar(k=0.4), vcov=matrix(0.04^2))
#mod3 <- FLSimpleModel(model=~exp(-a*age-0.5), params=FLPar(matrix(1, ncol=10)))
#mod4 <- FLSimpleModel(model=~1.5*a, params=FLPar(matrix(0.4, ncol=10)))
#mod5 <- mvrnorm(100, mod2)
#mod6 <- FLSimpleModel(model=~1.5*k*year, params=FLPar(k=0.4), vcov=matrix(0.04^2))
#mod6 <- mvrnorm(100, mod6)

#predict(mod1, age=0:15)
#predict(mod2)
#predict(mod3, age=0:15)
#predict(mod4)
#predict(mod5)
#predict(mod6, year=2000:2002)




