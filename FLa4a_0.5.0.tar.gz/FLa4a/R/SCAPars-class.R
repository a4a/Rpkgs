
#' a4aFitSA extends \code{"a4aFit"} class.
#'
#' Some details about this class and my plans for it in the body.
#'
#' \describe{
#'    \item{myslot1}{A logical keeping track of something.}
#'
#'    \item{myslot2}{An integer specifying something else.}
#' 
#'    \item{myslot3}{A data.frame holding some data.}
#'  }
#' @name SCAPars-class
#' @rdname SCAPars-class
#' @exportClass SCAPars
setClass("SCAPars",
        representation(
                n1model   = "submodel",
                qmodel    = "submodels",
                rmodel    = "submodel",
                fmodel    = "submodel"),
        prototype = prototype(
                n1model   = new("submodel"),
                qmodel    = new("submodels"),
                rmodel    = new("submodel"),
                fmodel    = new("submodel"))
)


# constructor
#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname a4aFitSA-methods
#'
#' @examples
#' data(ple4)
setGeneric("SCAPars", function(object, ...) standardGeneric("SCAPars"))

#' Title 
#' @name SCAPars
#' @docType methods
#' @rdname SCAPars-methods
#' @aliases SCAPars,SCAPars-method
setMethod("SCAPars", signature(object="missing"),
  function(...) {
    # empty
  	if(missing(...)){
	  	new("SCAPars")
    # or not
  	} else {
      args <- list(...)
	  args$Class <- 'SCAPars'
      do.call("new", args)
	  }
  }
)

# accessors

#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname a4aFitSA-methods
#'
#' @examples
#' data(ple4)
setGeneric("n1model", function(object, ...) standardGeneric("n1model"))

#' Title 
#' @name a4aFitSA
#' @docType methods
#' @rdname a4aFitSA-methods
#' @aliases a4aFitSA,a4aFitSA-method
setMethod("n1model", "SCAPars", function(object) object@n1model)

#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname a4aFitSA-methods
#'
#' @examples
#' data(ple4)
setGeneric("rmodel", function(object, ...) standardGeneric("rmodel"))

#' Title 
#' @name a4aFitSA
#' @docType methods
#' @rdname a4aFitSA-methods
#' @aliases a4aFitSA,a4aFitSA-method
setMethod("rmodel", "SCAPars", function(object) object@rmodel)

#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname a4aFitSA-methods
#'
#' @examples
#' data(ple4)
setGeneric("fmodel", function(object, ...) standardGeneric("fmodel"))

#' Title 
#' @name a4aFitSA
#' @docType methods
#' @rdname a4aFitSA-methods
#' @aliases a4aFitSA,a4aFitSA-method
setMethod("fmodel", "SCAPars", function(object) object@fmodel)

#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname a4aFitSA-methods
#'
#' @examples
#' data(ple4)
setGeneric("qmodel", function(object, ...) standardGeneric("qmodel"))

#' Title 
#' @name a4aFitSA
#' @docType methods
#' @rdname a4aFitSA-methods
#' @aliases a4aFitSA,a4aFitSA-method
setMethod("qmodel", "SCAPars", function(object) object@qmodel)

#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname a4aFitSA-methods
#'
#' @examples
#' data(ple4)
setGeneric("rPars", function(object, ...) standardGeneric("rPars"))

#' Title 
#' @name a4aFitSA
#' @docType methods
#' @rdname a4aFitSA-methods
#' @aliases a4aFitSA,a4aFitSA-method
setMethod("rPars", "SCAPars", function(object) object@rmodel@pars)

#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname a4aFitSA-methods
#'
#' @examples
#' data(ple4)
setGeneric("rCovar", function(object, ...) standardGeneric("rCovar"))

#' Title 
#' @name a4aFitSA
#' @docType methods
#' @rdname a4aFitSA-methods
#' @aliases a4aFitSA,a4aFitSA-method
setMethod("rCovar", "SCAPars", function(object) object@rmodel@covar)

#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname a4aFitSA-methods
#'
#' @examples
#' data(ple4)
setGeneric("rFrml", function(object, ...) standardGeneric("rFrml"))

#' Title 
#' @name a4aFitSA
#' @docType methods
#' @rdname a4aFitSA-methods
#' @aliases a4aFitSA,a4aFitSA-method
setMethod("rFrml", "SCAPars", function(object) object@rmodel@model)

#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname a4aFitSA-methods
#'
#' @examples
#' data(ple4)
setGeneric("fPars", function(object, ...) standardGeneric("fPars"))

#' Title 
#' @name a4aFitSA
#' @docType methods
#' @rdname a4aFitSA-methods
#' @aliases a4aFitSA,a4aFitSA-method
setMethod("fPars", "SCAPars", function(object) object@fmodel@pars)

#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname a4aFitSA-methods
#'
#' @examples
#' data(ple4)
setGeneric("fCovar", function(object, ...) standardGeneric("fCovar"))

#' Title 
#' @name a4aFitSA
#' @docType methods
#' @rdname a4aFitSA-methods
#' @aliases a4aFitSA,a4aFitSA-method
setMethod("fCovar", "SCAPars", function(object) object@fmodel@covar)

#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname a4aFitSA-methods
#'
#' @examples
#' data(ple4)
setGeneric("fFrml", function(object, ...) standardGeneric("fFrml"))

#' Title 
#' @name a4aFitSA
#' @docType methods
#' @rdname a4aFitSA-methods
#' @aliases a4aFitSA,a4aFitSA-method
setMethod("fFrml", "SCAPars", function(object) object@fmodel@model)

#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname a4aFitSA-methods
#'
#' @examples
#' data(ple4)
setGeneric("qPars", function(object, ...) standardGeneric("qPars"))

#' Title 
#' @name a4aFitSA
#' @docType methods
#' @rdname a4aFitSA-methods
#' @aliases a4aFitSA,a4aFitSA-method
setMethod("qPars", "SCAPars", function(object) object@qmodel@pars)

#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname a4aFitSA-methods
#'
#' @examples
#' data(ple4)
setGeneric("qCovar", function(object, ...) standardGeneric("qCovar"))

#' Title 
#' @name a4aFitSA
#' @docType methods
#' @rdname a4aFitSA-methods
#' @aliases a4aFitSA,a4aFitSA-method
setMethod("qCovar", "SCAPars", function(object) object@qmodel@covar)

#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname a4aFitSA-methods
#'
#' @examples
#' data(ple4)
setGeneric("qFrml", function(object, ...) standardGeneric("qFrml"))

#' Title 
#' @name a4aFitSA
#' @docType methods
#' @rdname a4aFitSA-methods
#' @aliases a4aFitSA,a4aFitSA-method
setMethod("qFrml", "SCAPars", function(object) object@qmodel@model)








