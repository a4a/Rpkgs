# submodel-class - «Short one line description»
# submodel-class

#' a4aFitSA extends \code{"a4aFit"} class.
#'
#' Some details about this class and my plans for it in the body.
#'
#' \describe{
#'    \item{myslot1}{A logical keeping track of something.}
#'
#'    \item{myslot2}{An integer specifying something else.}
#' 
#'    \item{myslot3}{A data.frame holding some data.}
#'  }
#' @name submodel-class
#' @rdname submodel-class
#' @exportClass submodel
setClass("submodel",
        representation(
                pars      = "FLQuant",
                covar      = "array",
                model      = "formula"),
        prototype = prototype(
                pars      = new('FLQuant'),
                covar      = array(),
                model      = formula(~NA))
)


# constructor

setGeneric("submodel", function(object, ...)
	standardGeneric("submodel"))

setMethod("submodel", signature(object="missing"),
  function(...) {
    # empty
  	if(missing(...)){
	  	new("submodel")
    # or not
  	} else {
      args <- list(...)
	  args$Class <- 'submodel'
      do.call("new", args)
	  }
  }
)

# accessors

setGeneric("pars", function(object, ...) standardGeneric("pars"))
setMethod("pars", "submodel", function(object) object@pars)

setMethod("model", "submodel", function(object) object@model)

setMethod("covar", "submodel", function(object) object@covar)


