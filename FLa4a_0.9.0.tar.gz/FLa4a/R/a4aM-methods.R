#' Method to compute natural mortality 
#'
#' @param object a \code{a4aM} object
#' @param grMod a \code{a4aGr} object to get the K from 
#' @param ... placeolder for covariates of the models. The names must match formula's variables (not parameters), with the exception of the \code{a4aGr} individual growth model. To use a growth model it must be called \code{grMod} and be of class \code{a4aGr}, in which case the parameters will be matched. The main objective if to be able to use \code{K} from von Bertalanffy models in M. 
#' @return a \code{FLQuant} object
#' @author EJ \email{ernesto.jardim@@jrc.ec.europa.eu}
#' @export
#' @examples
#' age <- 0:15
#' k <- 0.4
#' shp <- eval(as.list(~exp(-age-0.5))[[2]], envir=list(age=age))
#' lvl <- eval(as.list(~1.5*k)[[2]], envir=list(k=k))
#' M <- shp*lvl/mean(shp)
#' mod1 <- FLModelSim(model=~exp(-age-0.5))
#' mod2 <- FLModelSim(model=~1.5*k, params=FLPar(k=0.4))
#' m1 <- a4aM(shape=mod1, level=mod2)
#' rngmbar(m1)<-c(0,15)
#' m(m1, age=0:15)
#' all.equal(M, c(m(m1, age=0:15)))
#' # another example m
#' rngmbar(m1) <- c(2,4)
#' m(m1, age=2:10)
#' # with iters
#' mod2 <- FLModelSim(model=~k^0.66*t^0.57, params=FLPar(matrix(c(0.4,10,0.5,11), ncol=2, dimnames=list(params=c("k","t"), iter=1:2))), vcov=array(c(0.004, 0.00,0.00, 0.001), dim=c(2,2,2)))
#' m2 <- a4aM(shape=mod1, level=mod2)
#' m(m2, age=0:10)
#' m3 <- a4aM(shape=mod1, level=mvrnorm(100, mod2))
#' m(m3, age=0:15)
#' mod1 <- FLModelSim(model=~exp(-age-0.5))
#' mod3 <- FLModelSim(model=~1+b*v, params=FLPar(b=0.05))
#' mObj <- a4aM(shape=mod1, level=mvrnorm(100, mod2), trend=mod3, range=c(min=0,max=15,minyear=2000,maxyear=2003,minmbar=0,maxmbar=0))
#' m(mObj, v=1:4)

setMethod("m", "a4aM", function(object, grMod="missing", ...){
	args <- list(...)
	if(length(args)==0) args$nocovariateprovided <- TRUE
	if(!("age" %in% names(args))) args$age <- vecage(object)
	# else rngmbar(object) <- c(min(args$age), max(args$age)) 
	if(!("year" %in% names(args))) args$year <- vecyear(object)

	# check if there is a growth model to get K from
	if(!missing(grMod)){
		k <- c("k","K")[c("k","K") %in% dimnames(params(level(object)))$params]
		params(level(object))[k] <- getK(grMod)
	}

	args$object <- shape(object)
	shp <- do.call("predict", args)
	args$object <- level(object)
	lvl <- do.call("predict", args)
	args$object <- trend(object)
	trd <- do.call("predict", args)
	mat <- matrix(1, ncol=6, nrow=3, dimnames=list(model=c("shp","lvl","trd"), dim=c("age","year","unit", "season","area","iter")))
	mat["shp",c(1,6)] <- dim(shp)
	mat["lvl",c(1,6)] <- dim(lvl)
	mat["trd",c(2,6)] <- dim(trd)

	flq <- FLQuant(NA, dim=apply(mat,2,max), quant="age")
	dimnames(flq)[1:2] <- list(age=args$age,year=args$year)

	flqs <- flq
	flqs[] <- shp

	flql <- aperm(flq, c(6,1,2,3,4,5))
	flql[] <- lvl
	flql <- aperm(flql,c(2,3,4,5,6,1))

	flqt <- aperm(flq, c(2,6,1,3,4,5))
	flqt[] <- trd
	flqt <- aperm(flqt, c(3,1,4,5,6,2))
	m <- flqs*flql*flqt/quantMeans(flqs[as.character(vecmbar(object))])[rep(1,mat["shp",1])]
	FLQuant(m)
})

#' Method to simulate multivariate normal parameters
#'
#' @param n the number of simulations to be generated
#' @param mu a \code{a4aM} object
#' @return a \code{a4aM} object with n iterations 
#' @author EJ \email{ernesto.jardim@@jrc.ec.europa.eu}
#' @export
#' @examples
#' mod1 <- FLModelSim(model=~exp(-age-0.5))
#' mod2 <- FLModelSim(model=~k^0.66*t^0.57, params=FLPar(matrix(c(0.4,10,0.5,11), ncol=2, dimnames=list(params=c("k","t"), iter=1:2))), vcov=array(c(0.004, 0.00,0.00, 0.001), dim=c(2,2,2)))
#' mod3 <- FLModelSim(model=~1+b*v, params=FLPar(b=0.05))
#' mObj <- a4aM(shape=mod1, level=mod2, trend=mod3, range=c(min=0,max=15,minyear=2000,maxyear=2003,minmbar=0,maxmbar=0))
#' mObj <- mvrnorm(100, mObj)
#' m(mObj, v=c(1,1,1,1))

setMethod("mvrnorm", c(n="numeric", mu="a4aM", Sigma="missing",
	tol="missing", empirical="missing", EISPACK="missing"), function(n=1, mu) {
	args <- list()
	args$n <- n
	args$mu <- shape(mu)
	if(!is.empty(vcov(args$mu))) params(shape(mu)) <- params(do.call("mvrnorm", args))	

	args$mu <- level(mu)
	if(!is.empty(vcov(args$mu))) params(level(mu)) <- params(do.call("mvrnorm", args))	

	args$mu <- trend(mu)
	if(!is.empty(vcov(args$mu))) params(trend(mu)) <- params(do.call("mvrnorm", args))	

	mu	
})


