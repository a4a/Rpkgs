#' uses the user specified formula to build a model matrix
#'
#'
#' @param formula a formula object
#' @param df the data.frame to build the model matrix against
#' @return a matrix.
#' @note \code{getX} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
getX <- function(formula, df)
{
  mgcv <- !is.null(unlist(attr(terms.formula(formula, specials = c("s", "te", "t2")), "specials")))

 if (!mgcv) {
    X <- model.matrix(formula, df)
  } else {
    require(mgcv)
    formula <- eval(parse(text = paste("x ~", deparse(formula[[2]]))))
    X <- model.matrix.gam(gam(formula, data = df))
  }

  dimX <- dim(X)
  attributes(X) <- NULL
  dim(X) <- dimX

  X
}

#' adds extra columns to a data.frame using a named list of expressions
#'
#'
#' @param df a data.frame
#' @param extras a named list of expressions
#' @return a data.frame
#' @note \code{addExtras} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
addExtras <- function(df, extras = NULL) 
{
  if (!is.null(extras)) {
    df[names(extras)] <- lapply(extras, eval, df)
  }
  
  df
}

#' writes the data to be used in the ADMB optimisation to the data file
#'
#'
#' @param basedata a data.frame containing the catch and indices by year and age
#' @param natMor matrix of natural mortality
#' @param mat matrix of maturity
#' @param cWt matrix of catch weights
#' @param sWt matrix of stock weights
#' @param wkdir used to set a working directory for the admb optimiser.
#' @return NULL
#' @note \code{toADMB} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
toADMB <- function(basedata, center.log, natMor, mat, cWt, sWt, wkdir)
{
  doone <- function(i)
  {
    x <- basedata[[i]]
    obs <- as.vector(x) * exp(- center.log[i]) # TODO convert a4a executable to take log obs as input
    y <- as.numeric(colnames(x)[col(x)])
    a <- as.numeric(rownames(x)[row(x)])
    ret <- cbind(i,y,a,obs)
    ret <- ret[complete.cases(ret),]
  }

  all <- do.call(rbind,lapply(1:length(basedata),doone))

  filename <- paste0(wkdir,'/a4a.dat')

  cat("# Data format for the a4a model\n# number of observations\n",nrow(all),
    "\n# Observation matrix\n# fleet\tyear\tage\tobservation\n", file=filename)
  write.table(all, row.names=FALSE, col.names=FALSE, quote=FALSE, sep='\t', file=filename, append=TRUE)

  cat("# Natural mortality\n", file=filename, append=TRUE)
  write.table(t(natMor), row.names=FALSE, col.names=FALSE, quote=FALSE, sep='\t', file=filename, append=TRUE)

  cat("# Maturity\n", file=filename, append=TRUE)
  write.table(t(mat), row.names=FALSE, col.names=FALSE, quote=FALSE, sep='\t', file=filename, append=TRUE)

  cat("# Catch Weights\n", file=filename, append=TRUE)
  write.table(t(cWt), row.names=FALSE, col.names=FALSE, quote=FALSE, sep='\t', file=filename, append=TRUE)

  cat("# Stock weights\n", file=filename, append=TRUE)
  write.table(t(sWt), row.names=FALSE, col.names=FALSE, quote=FALSE, sep='\t', file=filename, append=TRUE)

  invisible(NULL)
}

#' writes model configuration information to the model.cfg file
#'
#'
#' @param surveytime vector of showing when in the year the surveys take place
#' @param fbar numeric vector of the fbar range
#' @param plusgroup logical vector to say whether the oldest age is a plus group or not
#' @param srrCV if negative the stock recruitme model is not used if positive the value is used as the CV of the relationship.  
#'              The model is hard coded as the beverton holt curve for now.
#' @param randomF a flag to turn off or on the use of the prior for log fishing mortality
#' @param randomQ a flag to turn off or on the use of the prior for log survey catchability
#' @param basedata a data.frame containing the catch and indices by year and age
#' @param wkdir used to set a working directory for the admb optimiser.
#' @return NULL
#' @note \code{setupMain} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
setupMain <- function(surveytime, fbar, plusgroup, srrCV, randomF, randomQ, basedata, wkdir) 
{
  filename <- paste0(wkdir,'/model.cfg')

  cat("## A4a configuration\n##\n# Observation variance parameter coupling columns are ages row are fleets\n",
      file=filename)
  vars <- matrix(1:length(basedata), length(basedata), nrow(basedata[[1]]))
  #vars <- rbind(c(1:2,rep(2,8)), c(3,rep(4, 9)), c(5,rep(6, 9)), c(7,rep(8, 9)))
  write.table(vars, row.names=FALSE, col.names=FALSE, quote=FALSE, sep=' ', file=filename, append=TRUE)
  cat("# survey time as a fraction into the year (one for each survey)\n",
       paste(surveytime, collapse = " "), 
    "\n# fbar range\n",
       paste(fbar, collapse = " "),
    "\n# last age group considered plus group 0=no 1=yes\n",
       plusgroup,
    "\n# enforce BH stock recruitment by penalized likelihood", 
    "\n# give the CV, or a negative number if turned off\n",
       srrCV,
    "\n# flag to turn F-deviations on and off 0=off 1=on\n",
       randomF,
    "\n# flag to turn Q-deviations on and off 0=off 1=on\n",
       randomQ, "\n",
      file=filename, append=TRUE, sep="")  

  invisible(NULL)
}

#' writes the configuration file of the fishing mortality model
#'
#'
#' @param formula a formula object depicting the model to be used
#' @param basedata a data.frame containing the catch and indices by year and age
#' @param extras a named list of expressions used to add covariates to the model
#' @param wkdir used to set a working directory for the admb optimiser.
#' @return NULL
#' @note \code{setupF} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
setupF <- function(formula, basedata, extras = NULL, wkdir)
{
  x <- basedata[[1]]
  y <- as.numeric(colnames(x))
  a <- as.numeric(rownames(x))

  df <- addExtras(expand.grid(year = y, age = a, x = 1), extras)

  Xf <- getX(formula, df)

  filename <- paste0(wkdir,'/fmodel.cfg')

  cat("# F model config for the a4a model\n# ages\n",range(a),
    "\n# years\n", range(y), 
    "\n# model params\n", ncol(Xf), 
    "\n# design matrix\n",
      file=filename)
  write.table(Xf, row.names=FALSE, col.names=FALSE, quote=FALSE, sep='\t', file=filename, append=TRUE)

  invisible(NULL)
}

#' writes the configuration file of the survey catchability model
#'
#'
#' @param formula a formula object depicting the model to be used
#' @param basedata a data.frame containing the catch and indices by year and age
#' @param extras a named list of expressions used to add covariates to the model
#' @param wkdir used to set a working directory for the admb optimiser.
#' @return NULL
#' @note \code{setupQ} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
setupQ <- function(formula.list, basedata, extras = NULL, wkdir)
{
  filename <- paste0(wkdir,'/qmodel.cfg')

  cat("# Q model config for the a4a model\n", file = filename)

  doone <- function(i) {  
    x <- basedata[[i]]
    y <- as.numeric(colnames(x))
    a <- as.numeric(rownames(x))

    df <- addExtras(expand.grid(year = y, age = a, x = 1), extras)

    Xq <- getX(formula.list[[i - 1]], df)

    cat("# survey", i-1,
      "\n# ages\n",range(a),
      "\n# years\n", range(y), 
      "\n# model params\n", ncol(Xq), 
      "\n# design matrix\n",
        file=filename, append=TRUE)
    write.table(Xq, row.names=FALSE, col.names=FALSE, quote=FALSE, sep='\t', file=filename, append=TRUE)
  }

  for (i in 2:length(basedata)) doone(i)
  invisible(NULL)
}

#' writes the configuration file of the recruitment model
#'
#'
#' @param formula a formula object depicting the model to be used
#' @param basedata a data.frame containing the catch and indices by year and age
#' @param extras a named list of expressions used to add covariates to the model
#' @param wkdir used to set a working directory for the admb optimiser.
#' @return NULL
#' @note \code{setupR} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
setupR <- function(formula, basedata, extras = NULL, wkdir)
{
  x <- basedata[[1]]
  y <- as.numeric(colnames(x))

  df <- addExtras(expand.grid(year = y, x = 1), extras)

  Xr <- getX(formula, df)

  filename <- paste0(wkdir,'/rmodel.cfg')

  cat("# R model config for the a4a model\n# years\n", range(y), 
    "\n# model params\n", ncol(Xr), 
    "\n# design matrix\n",
    file=filename)
  write.table(Xr, row.names=FALSE, col.names=FALSE, quote=FALSE, sep='\t', file=filename, append=TRUE)

  invisible(NULL)
}


#' returns the covariance matrix of the specified Gaussian markov random feild model
#'
#'
#' @param n integer giving the size of the random feild
#' @param model chatacter giving the name of the GMRF
#' @param tau numeric giving the multiplier of the structure matrix for the model
#' @return a covariance matrix
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
getCov <- function(n, model, tau)
{
  model <- match.arg(model, c("iid","rw1","rw2"))
  # try and add AR1 - need extra param for that though...

  if (model == "iid") {
    Cov <- diag(n) * tau

  } else if (model %in% c("rw1", "rw2")) {
    Q <- Qfunc(n, type = model) / tau
    # make positive definate
    Q[] <- c(Q) + rowSums(apply( eigen(Q)$vectors, 2, function(x) outer(x, x)))
    Cov <- solve(Q)
  }

  Cov
}

#' writes the configuration file of the fishing mortality prior model
#'
#'
#' @param model chatacter giving the name of the GMRF
#' @param tau numeric giving the multiplier of the structure matrix for the model
#' @param basedata a data.frame containing the catch and indices by year and age
#' @param wkdir used to set a working directory for the admb optimiser.
#' @return NULL
#' @note \code{setupFprior} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
setupFprior <- function(model = "iid", tau = 0.05, basedata, wkdir)
{
  filename <- paste0(wkdir,'/fprior.cfg')

  x <- basedata[[1]]
  a <- as.numeric(rownames(x))

  Covf <- getCov(length(a), model, tau)

  cat("# F prior config for the a4a model\n# ages\n",range(a),
      "\n# prior\n",
        file=filename)
  write.table(Covf, row.names=FALSE, col.names=FALSE, quote=FALSE, sep='\t', file=filename, append=TRUE)

  invisible(NULL)
}


#' writes the configuration file of the survey catchability prior model
#'
#'
#' @param model chatacter giving the name of the GMRFs to use,  one for each survey.
#' @param tau numeric giving the multiplier of the structure matrix for the model - one for each survey.
#' @param basedata a data.frame containing the catch and indices by year and age.
#' @param wkdir used to set a working directory for the admb optimiser.
#' @return NULL
#' @note \code{setupQprior} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
setupQprior <- function(model =  "iid", tau = 0.05, basedata, wkdir)
{
  filename <- paste0(wkdir,'/qprior.cfg')
  # recycle model to correct length
  model <- model[(1:length(basedata[-1])-1) %% length(model) + 1]
  tau <- tau[(1:length(basedata[-1])-1) %% length(tau) + 1]

  cat("# Q prior config for the a4a model\n", file = filename)

  doone <- function(i) {  
    x <- basedata[[i]]
    a <- as.numeric(rownames(x))

    Covq <- getCov(length(a), model[i-1], tau[i-1])

    cat("# survey", i-1,
      "\n# ages\n",range(a),
      "\n# prior\n",
        file=filename, append=TRUE)
    write.table(Covq, row.names=FALSE, col.names=FALSE, quote=FALSE, sep='\t', file=filename, append=TRUE)
  }

  for (i in 2:length(basedata)) doone(i)

  invisible(NULL)
}


