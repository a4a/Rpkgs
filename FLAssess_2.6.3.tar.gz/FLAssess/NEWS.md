# FLAssess 2.6.3

## DEPRECATED

- stf() has been moved to the FLash and FLasher pkgs.

# FLAssess 2.6.2


## DEPRECATED

- retro methods had been deprecated, now their Rd files have been deleted too.

