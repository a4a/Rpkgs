
library(testthat)
library(FLasher)

test_check("FLasher")
