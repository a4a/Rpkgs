


#' The user interface to the a4a fitting routine.
#'
#'
#' @param fmodel a formula object depicting the model for log fishing mortality at age
#' @param qmodel a list of formula objects depicting the models for log survey catchability at age
#' @param rmodel a formula object depicting the model for log recruitment
#' @param stock an FLStock object containing catch and stock information
#' @param indices an FLIndices object containing survey indices 
#' @param fmodel.extra a named list of expressions used to add covariates to the model for log fishing mortality at age
#' @param qmodel.extra a named list of expressions used to add covariates the models for log survey catchability at age
#' @param wkdir used to set a working directory for the admb optimiser.  If wkdir is set all admb files are saved to this folder otherwise they are deleted.
#' @param verbose if true admb fitting information is printed to the screen
#' @return an FLa4aFit object
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
#' @examples
#' data(ple4)
#' data(ple4.indices)
#' # define sub models
#' fmodel <- ~ s(age, k=4) + factor(year)
#' qmodel <- list(~ s(age, k=4), ~ s(age, k=4))
#' rmodel <- ~ factor(year)
#' fit <- a4aFit(fmodel, qmodel, rmodel, ple4, ple4.indices[1:2], verbose = TRUE)
#' fit
a4aFit <- function(fmodel, qmodel, rmodel, 
                   stock, indices, 
                   fmodel.extra = NULL, qmodel.extra = NULL,
                   wkdir = NULL, verbose = FALSE)
{
  args <- defaultSettings()
  args $ fmodel <- fmodel
  args $ qmodel <- qmodel
  args $ rmodel <- rmodel

  if (!is.null(fmodel.extra)) args $ fmodel.extra <- fmodel.extra
  if (!is.null(qmodel.extra)) args $ qmodel.extra <- qmodel.extra

  # data
  args <- c(args, getData(stock, indices))

  # other arguments
  args $ surveytime <- unname(sapply(indices, function(x) mean(dims(x) $ startf, dims(x) $ endf)))
  args $ fbar <-  unname(range(stock)[c("minfbar","maxfbar")])
  args $ plusgroup <- as.integer( !is.na(range(stock)["plusgroup"]), range(stock)["plusgroup"] >= range(stock)["max"] )
  args $ srrCV <- -1
  args $ wkdir <- wkdir
  args $ verbose <- verbose

  # fit model
  fit <- do.call(doRun, args)
  fit@name <- stock@name
  fit@desc <- stock@desc
  fit@models$fmodel <- fmodel
  fit@models$qmodel <- qmodel
  fit@models$rmodel <- rmodel

  fit
}


#' sets up some default settings such as no random model, no covariates
#'
#'
#' @return a list of arguments to \code{doRun}
#' @note \code{defaultSettings} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
defaultSettings <- function()
{
  randomF <- randomQ <- 0 

  # to begin with no extra columns in 'data' frame
  fmodel.extra <- qmodel.extra <- rmodel.extra <- NULL

  # although unused, need to specify the random models for F and Q for now
  fprior <- "iid"
  ftau <- 0.05

  qprior <- c("iid","iid")
  qtau <- c(0.01, 0.01)

  as.list(environment())
}


#' Extracts the required data from an FLStock and FLIndices and 
#' returns in a list
#'
#'
#' @param stk an FLStock object containing catch and stock information
#' @param ind an FLIndices object containing survey indices 
#' @return a list containing a data.frame containing all observations: catches and indices
#' @note \code{getData} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
getData <- function(stk, ind)
{
  basedata <- c(list(catch=catch.n(stk)[drop=TRUE]),
              lapply(ind, function(x) index(x)[drop=TRUE])) 

  natMor <-        m(stk)[drop=TRUE]
  mat    <-      mat(stk)[drop=TRUE]
  sWt    <- stock.wt(stk)[drop=TRUE]
  cWt    <- catch.wt(stk)[drop=TRUE]

  list( basedata = basedata, natMor = natMor, mat = mat, cWt = cWt, sWt = sWt)
}


#' creates the input files for the ADMB code, runs the ADMB executable and
#' reads the output from the ADMB output files creating an FLa4aFit object
#'
#' @param fmodel a formula object depicting the model for log fishing mortality at age
#' @param fmodel.extra a named list of expressions used to add covariates to the model for log fishing mortality at age
#' @param fprior a character string giving the name of a prior model
#' @param ftau a numeric giving the parameters of the log fishing mortality prior model
#' @param qmodel a list of formula objects depicting the models for log survey catchability at age
#' @param qmodel.extra a named list of expressions used to add covariates the models for log survey catchability at age
#' @param qprior a character string giving the names of a prior model
#' @param qtau a numeric giving the parameters of the log survey catchability prior models
#' @param rmodel a formula object depicting the model for log recruitment
#' @param rmodel.extra a named list of expressions used to add covariates the models for log recruitment
#' @param rprior a character string giving the name of a prior model
#' @param rtau a numeric giving the parameters of the log recruitment prior model
#' @param basedata a data.frame containing the catch and indices by year and age
#' @param natMor matrix of natural mortality
#' @param mat matrix of maturity
#' @param cWt matrix of catch weights
#' @param sWt matrix of stock weights
#' @param surveytime vector of showing when in the year the surveys take place
#' @param fbar numeric vector of the fbar range
#' @param plusgroup logical vector to say whether the oldest age is a plus group or not
#' @param srrCV if negative the stock recruitme model is not used if positive the value is used as the CV of the relationship.  
#'              The model is hard coded as the beverton holt curve for now.
#' @param randomF a flag to turn off or on the use of the prior for log fishing mortality
#' @param randomQ a flag to turn off or on the use of the prior for log survey catchability
#' @param wkdir used to set a working directory for the admb optimiser.  If wkdir is set all admb files are saved to this folder otherwise they are deleted.
#' @param verbose if true admb fitting information is printed to the screen
#' @param file.log if not null then the ADMB fitting progress will be written to a file with this name
#' @return an FLa4aFit object
#' @note \code{doRun} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
doRun <- function(fmodel, fmodel.extra, fprior, ftau,
                  qmodel, qmodel.extra, qprior, qtau,
                  rmodel, rmodel.extra, 
                  basedata, natMor, mat, cWt, sWt, 
                  surveytime, fbar, plusgroup, srrCV, 
                  randomF, randomQ,
                  wkdir = NULL, verbose = FALSE, file.log = NULL)
{

  
  if (is.null(wkdir)) keep <- FALSE else keep <- TRUE 
  if (is.null(wkdir)) wkdir <- tempdir()
  # add process ID to end of working directory name for parallel applications
  wkdir <- paste0(wkdir, Sys.getpid())
  if (is.null(file.log)) file.log <- tempfile("a4alogfile", tmpdir=wkdir, fileext=".txt")


  # TODO check if wkdir exists, maybe delete?...
  dir.create(wkdir, showWarnings = FALSE)
 
  # run setup functions
  # write data
  toADMB(basedata, natMor, mat, cWt, sWt, wkdir)
  # write config files
  setupMain(surveytime, fbar, plusgroup, srrCV, randomF, randomQ, basedata, wkdir) # 
  setupF(fmodel, basedata, fmodel.extra, wkdir)
  setupQ(qmodel, basedata, qmodel.extra, wkdir)
  setupR(rmodel, basedata, rmodel.extra, wkdir)

  setupFprior(fprior, tau = ftau, basedata, wkdir)
  setupQprior(qprior, tau = qtau, basedata, wkdir)

  # run executable in wkdir directory
  if (os.type("linux")) {
    if (verbose) {
      echoc <- system(paste0("cd ", shQuote(wkdir), ";a4a"))
    } else {
      echoc <- system(paste0("cd ", shQuote(wkdir), ";a4a > ", file.log))
    }
  } else if (os.type("windows")) {
    if (verbose) {
      echoc <- shell(paste0("cd ", wkdir, " & a4a"))
    } else {
      echoc <- shell(paste0("cd ", wkdir, " & a4a > ", file.log))
    }
  }
  if (echoc != 0) stop("bad return from a4a executlable\n")

  # read admb output from file
  fit <- geta4aFit(wkdir)

  # remove temporary directory - keep only true when dir is temp dir
  if (!keep) unlink(wkdir)

  fit
}





#' Calls and processes the output from read.fit
#'
#'
#' @param wkdir the working directory where the ADMB output files reside 
#' @return an FLa4aFit object
#' @note \code{geta4aFit} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
geta4aFit <- function(wkdir) 
{
  fit   <- read.fit(paste0(wkdir, '/a4a'))
  fit$N <- as.matrix(read.table(paste0(wkdir, '/n.out'), header = FALSE))
  fit$F <- as.matrix(read.table(paste0(wkdir, '/f.out'), header = FALSE))

  ages  <- sort(unique(fit$res$age))
  years <- sort(unique(fit$res$year))

  colnames(fit$N) <- colnames(fit$F) <- ages
  rownames(fit$N) <- rownames(fit$F) <- years

  noQyears <- rowSums(table(fit $ res $ fleet, fit $ res $ year)[-1, , drop = FALSE] > 0)
  
  readQ <- function(i) {
    ret <- read.table(paste0(wkdir, '/q.out'), header = FALSE, 
                     skip = c(0, cumsum(noQyears))[i],
                     nrows = noQyears[i])
    ret <- as.matrix(ret)
    rownames(ret) <- sort(unique(fit $ res $ year[fit $ res $ fleet == i + 1]))
    colnames(ret) <- sort(unique(fit $ res $ age[fit $ res $ fleet == i + 1]))
    ret
  }

  fit$logQ <- lapply(1:length(noQyears), readQ)

  fit <- fit2a4aFit(fit)

  fit
}


#' Extracts the ADMB output from the standard ADMB output files given a directory
#'
#'
#' @param file an FLStock object containing catch and stock information
#' @return a list containing the summary of the ADMB optimisation
#' @note \code{read.fit} is intended to be used internally
#' @author Anders Nielsen \email{an@@aqua.dtu.dk}
#' @export
read.fit<-function(file) {
  #
  #Function to read a basic AD Model Builder fit.
  #
  #Use for instance by:
  #
  #simple.fit <- read.fit('c:/admb/examples/simple')
  #
  #Then the object 'simple.fit' is a list containing sub-objects
  # 'names', 'est', 'std', 'cor', and 'cov' for all model
  # parameters and sdreport quantities.
  #
  ret <- list()
  ret$res <- read.table(paste(file,'.res',sep=''),header=TRUE)
  parfile <- as.numeric(scan(paste(file,'.par', sep=''), what='', n=16, quiet=TRUE)[c(6,11,16)])
  ret$nopar <- as.integer(parfile[1])
  ret$nlogl <- parfile[2]
  ret$maxgrad<-parfile[3]
  file<-paste(file,'.cor', sep='')
  lin<-readLines(file)
  ret$npar<-length(lin)-2
  ret$logDetHess<-as.numeric(strsplit(lin[1], '=')[[1]][2])
  sublin<-lapply(strsplit(lin[1:ret$npar+2], ' '),function(x)x[x!=''])
  ret$names<-unlist(lapply(sublin,function(x)x[2]))
  ret$est<-as.numeric(unlist(lapply(sublin,function(x)x[3])))
  ret$std<-as.numeric(unlist(lapply(sublin,function(x)x[4])))
  ret$cor<-matrix(NA, ret$npar, ret$npar)
  corvec<-unlist(sapply(1:length(sublin), function(i)sublin[[i]][5:(4+i)]))
  ret$cor[upper.tri(ret$cor, diag=TRUE)]<-as.numeric(corvec)
  ret$cor[lower.tri(ret$cor)] <- t(ret$cor)[lower.tri(ret$cor)]
  ret$cov<-ret$cor*(ret$std%o%ret$std)
  return(ret)
}



#' Proccesses a list of ADMB output into a FLa4aFit object.  This function is called by geta4aFit.
#'
#'
#' @param fit a list of ADMB output
#' @return an FLa4aFit object
#' @note \code{fit2a4aFit} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
#' @export
fit2a4aFit <- function(fit)
{

  ind.names <- paste("survey", 1:length(fit $ logQ))

  stk.n <- t(fit $ N)
  names(dimnames(stk.n)) <- c("age","year")

  hvst <- t(fit $ F)
  names(dimnames(hvst)) <- c("age","year")

  logq <- lapply(fit $ logQ, function(x) {x <- t(x); names(dimnames(x)) <- c("age","year"); FLQuant(x)})
  names(logq) <- ind.names
  
  getres <- function(x, what, .fleet) {
    x <- cbind(subset(fit $ res, fleet == .fleet)[c(what,"age", "year")], unit = "unique", season = "all", area = "unique", iter = 1)
    names(x)[1] <- "data"
    as.FLQuant(x)
  }
  getres2 <- function(x, what) {
    x <- lapply(sort(unique(x$fleet))[-1], function(fleet) getres(x, what, fleet))
    names(x) <- ind.names
    do.call(FLQuants, x)
  }

  out <- new("FLa4aFit")
  out @ stock.n <- FLQuant(stk.n)
  out @ harvest <- FLQuant(hvst, units = "f")

  out @ index.name <- ind.names
  out @ logq <- do.call(FLQuants, logq)

  out @ catch.n <- getres(fit $ res, "obs", 1)
  out @ catch.var <- getres(fit $ res, "sd", 1)^2
  out @ catch.hat <- getres(fit $ res, "pred", 1)
  out @ catch.res <- getres(fit $ res, "res", 1)

  out @ index <- getres2(fit $ res, "obs")
  out @ index.var <- lapply(getres2(fit $ res, "sd"), "^", 2)
  out @ index.hat <- getres2(fit $ res, "pred")
  out @ index.res <- getres2(fit $ res, "res")

#  out @ logQ <- out @ index
#  for (i in 1:length(out @ logQ)) out @ logQ[[i]] @ .Data <- fit $ logQ[[i]]

  out @ fit.sum <- with(fit, c(nopar = nopar, nlogl = nlogl, maxgrad = maxgrad, npar = npar, logDetHess = logDetHess))
  out @ coefficients <- fit $ est
  out @ covariance <- fit $ cov
  names(out @ coefficients) <- fit $ names

  dmns <- dimnames(stock.n(out))[2]
  fmean <- FLQuant(fit $ est[fit $ names == 'ssb'], dimnames = dmns)
  fsd <- FLQuant(fit $ std[fit $ names == 'ssb'], dimnames = dmns)
  out @ ssb <- FLQuantPoint(mean = fmean)
  out @ ssb[,,,,,"var"]    <- fsd^2 
  out @ ssb[,,,,,"median"] <- fmean 
  out @ ssb[,,,,,"uppq"]   <- fmean + 1.96 * fsd 
  out @ ssb[,,,,,"lowq"]   <- fmean - 1.96 * fsd 

  dmns <- dimnames(stock.n(out))[2]
  fmean <- FLQuant(fit $ est[fit $ names == 'fbar'], dimnames = dmns)
  fsd <- FLQuant(fit $ std[fit $ names == 'fbar'], dimnames = dmns)
  out @ fbar <- FLQuantPoint(mean = fmean, units = "f")
  out @ fbar[,,,,,"var"]    <- fsd^2 
  out @ fbar[,,,,,"median"] <- fmean 
  out @ fbar[,,,,,"uppq"]   <- fmean + 1.96 * fsd 
  out @ fbar[,,,,,"lowq"]   <- fmean - 1.96 * fsd 

  out
}


