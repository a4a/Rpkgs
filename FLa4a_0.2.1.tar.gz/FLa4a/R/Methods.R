
#' Hello 
#' @name show
#' @docType methods
#' @rdname show-methods
#' @aliases show,FLa4aFit-method
setMethod("show", signature(object = "FLa4aFit"),
  function(object) 
  {
    cat("\na4a model fit for:", object@name, "\n")
#    cat(object@desc, "\n")
    cat("Formulas:\n")
    cat("   log F", format(object@models$fmodel), "\n")
    sapply(object@models$qmodel, function(m) cat("   log Q", format(m), "\n"))
    cat("   log R", format(object@models$rmodel), "\n")

#    print(x$formula)
    cat("Total model degrees of freedom", object@fit.sum["nopar"], "\n")
#    cat("\nEstimated degrees of freedom:\n")
    #TODO check that nlogl is not 2 x neg loglik
    cat("\n            AIC: ", 2*(object@fit.sum["nlogl"] + object@fit.sum["nopar"]), sep = "")
    cat("\n log Likelihood: ", -1 * object@fit.sum["nlogl"], "\n", sep = "")
 })


#' Hello 
#' @name show
#' @docType methods
#' @rdname show-methods
#' @aliases show,FLa4aFit-method
setMethod("plot", signature(x = "FLa4aFit", y = "missing"),
  function (x, y, ratio = 1.5, file = "", onefile = TRUE, ...) 
  {

    if (file == "") {
      sub.dev.new <- function() dev.new(width = 7 * ratio, height = 7)
      sub.dev.new()
    }
    else { # will need different dev.new if file == pdf
      sub.dev.new <- function() NULL
      file <- if (onefile) paste0(file, ".pdf") else paste0(file, "%03d.pdf")
      pdf(onefile = onefile, file = file, width = 6 * ratio, height = 6)
    }

    ages  <- as.numeric(dimnames(stock.n(x)) $ age)
    years <- as.numeric(dimnames(stock.n(x)) $ year)

    cols <- 
     c(rgb(215, 48, 39, max = 255), 
       rgb(252, 141, 89, max = 255),
       rgb(254, 224, 144, max = 255),
       rgb(224, 243, 248, max = 255),
       rgb(145, 191, 219, max = 255),
       rgb(69, 117, 180, max = 255))

    # N plot
    matplot(years, t(stock.n(x)[drop=TRUE]) * 1e-5,  
            ylab ="N at age ('00 000s)", xlab = "Year", 
            col = colorRampPalette(cols[c(1, 6)])(length(ages)),
            type ='l', lty = 1, lwd = 2, las = 1)

    fest <- harvest(x)[drop=TRUE]

    sub.dev.new()
    # F plot
    matplot(years, t(fest),  
            ylab = "F at age", xlab = "Year", 
            col = colorRampPalette(cols[c(1, 6)])(length(ages)),
            type = 'l', lty = 1, lwd = 2, las = 1)


    sub.dev.new()
    # another F plot
    p <- matrix.plot(fest, cols = cols, xlab = "Year", ylab = "Age")
    print(p)

    sub.dev.new()
    # Yet another F plot
    p <- wireframe(fest, zlim = c(min(fest), max(fest)), nlevels = 10,
            panel.3d.wireframe = panel.3d.levelplot, cols = cols,
            at = pretty(fest, 10),
            shade = TRUE, panel.aspect = 1/ratio, aspect=c(length(years)/length(ages), 2),
            col.regions = colorRampPalette(rev(cols))(100),
            screen = list(z = 240, x = -60),
            par.settings = list(axis.line = list(col = "transparent")),
            par.box = c(col = "transparent"))

    print(p)


    sub.dev.new()
    # fbar plot
    plotError(years, fbar(x)[,,,,,"mean",drop=TRUE], sqrt(fbar(x)[,,,,,"var",drop=TRUE]), 
              ylab = 'Fbar', xlab = "Year", cols = colorRampPalette(cols[5:6])(3))

    sub.dev.new()
    # ssb plot
    plotError(years, ssb(x)[,,,,,"mean",drop=TRUE] * 1e-3, sqrt(ssb(x)[,,,,,"var",drop=TRUE]) * 1e-3, 
              ylab = "SSB ('000 tonnes)", xlab = "Year", cols = colorRampPalette(cols[5:6])(3))


    # q plots
    for (i in 1:length(x @ logq)) {
      qest <- logq(x)[[i]]
      qages  <- as.numeric(dimnames(qest) $ age)
      qyears <- as.numeric(dimnames(qest) $ year)

      sub.dev.new()
      matplot(qages, qest[drop=TRUE],  
              ylab="log catchability", xlab="Age", main = names(x @ logq)[i],
              col = colorRampPalette(cols[c(1, 6)])(length(qyears)),
              type ='l', lty = 1, lwd = 2, las = 1)

      p <- wireframe(qest[drop=TRUE], drape = TRUE, colorkey = FALSE,
             # screen value tuned to ple4.indices[1:2]
             screen = list(z = ifelse(i==1, -1, 1) * 30, x = -60), 
             col.regions = colorRampPalette(rev(cols))(100),
             main = names(x @ logq)[i], zlab = "", panel.aspect = 1/ratio)
      sub.dev.new()
      print(p) 
    }

    sub.dev.new()
    # Residual plot 
    div <- list(c(1,1), c(2,1), c(3,1), c(2,2), c(3,2), c(3,2), c(3,3), c(3,3), c(3,3), c(4,3), c(4,3), c(4,3))
    nind <- length(x @ logq)
    op <- par(mfrow = div[[nind + 1]], mar = c(4,4,1,2), mgp = c(2,1,0))
    ylim <- range(as.numeric(dimnames(stock.n(x)) $ age)) + c(-.5, .5)
    xlim <- range(as.numeric(dimnames(stock.n(x)) $ year)) + c(-.5, .5)

    res <- x @ catch.res
    ages  <- as.numeric(dimnames(res) $ age)
    years <- as.numeric(dimnames(res) $ year)

    bp(rep(years, each = length(ages)), rep(ages, length(years)), 
       c(res[drop=TRUE]), 
       ylim = ylim, xlim = xlim, 
       xlab = 'year', ylab = 'Age', main = "Catch", 
       scale = 3, las = 1)

    for(i in 1:nind) {
      res <- index.res(x)[[i]]
      ages  <- as.numeric(dimnames(res) $ age)
      years <- as.numeric(dimnames(res) $ year)

      bp(rep(years, each = length(ages)), rep(ages, length(years)), 
         c(res[drop=TRUE]), 
         ylim = ylim, xlim = xlim, 
         xlab = 'year', ylab = 'Age', main = names(x @ logq)[i], 
         scale = 3, las = 1)
    }

    if (file != "") dev.off()
  }
)


#' Hello 
#' @name ssb
#' @docType methods
#' @rdname ssb-methods
#' @aliases ssb,FLa4aFit-method
setMethod("ssb", signature(object = "FLa4aFit"),
  function (object, ...) 
  {
    object @ ssb
  })

#' Hello 
#' @name fbar
#' @docType methods
#' @rdname fbar-methods
#' @aliases fbar,FLa4aFit-method
setMethod("fbar", signature(object = "FLa4aFit"),
  function (object, ...) 
  {
    object @ fbar
  })


#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname logq-methods
#'
#' @examples
#' data(ple4)
#' genFLQuant(harvest(ple4), method = "ac")
setGeneric("logq", function(object, ...) standardGeneric("logq"))

#' @rdname logq-methods
#' @aliases logq,FLa4aFit-method
setMethod("logq", signature(object = "FLa4aFit"),
  function(object) {
	object @ logq
  })



#' Calculate the median accross iterations
#'
#' @param object an FLQuant with iters
#'
#' @param ... Additional argument list that might not ever
#'  be used.
#'
#' @return an FLQuant
#' 
#' @seealso \code{\link{print}} and \code{\link{cat}}
#' 
#' @export
#' @docType methods
#' @rdname coef-methods
#'
#' @examples
#' data(ple4)
#' genFLQuant(harvest(ple4), method = "ac")
setGeneric("coef", function(object, ...) standardGeneric("coef"))

#' @rdname coef-methods
#' @aliases coef,FLa4aFit-method
setMethod("coef", signature(object = "FLa4aFit"),
  function(object) {
	object @ coefficients[1:fit@fit.sum["nopar"]]
  })

