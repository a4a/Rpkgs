# FLa4aFit-class - «Short one line description»
# FLa4aFit-class

## FLa4aFit             {{{
validFLa4aFit <- function(object){

        # All FLQuant objects must have same dimensions
        Dim <- dim(object@stock.n)
        if (!all(dim(object@harvest) == Dim))
                return("stock.n and harvest arrays must have same dimensions")

        # Everything is fine
        return(TRUE)
}
#' FLa4aFit extends \code{"FLAssess"} class.
#'
#' Some details about this class and my plans for it in the body.
#'
#' \describe{
#'    \item{myslot1}{A logical keeping track of something.}
#'
#'    \item{myslot2}{An integer specifying something else.}
#' 
#'    \item{myslot3}{A data.frame holding some data.}
#'  }
#' @name FLa4aFit-class
#' @rdname FLa4aFit-class
#' @exportClass FLa4aFit
setClass("FLa4aFit",
        representation(
                "FLAssess",
                logq         = "FLQuants",
                catch.res    = "FLQuant",
                catch.hat    = "FLQuant",
                catch.var    = "FLQuant",
                call         = "character",
                fit.sum      = "numeric",
                coefficients = "numeric",
                covariance   = "matrix",
                models       = "list",
                fbar         = "FLQuantPoint",
                ssb          = "FLQuantPoint"),
        prototype = prototype(
                logq       = new('FLQuants'),
                catch.res  = new('FLQuant'),
                catch.hat  = new('FLQuant'),
                catch.var  = new('FLQuant'),
                call       = "new(\"FLa4aFit\")",
                fit.sum      = new('numeric'),
                coefficients = new('numeric'),
                covariance   = new('matrix'),
                models       = new('list'),
                fbar         = new('FLQuantPoint'),
                ssb          = new('FLQuantPoint')),
        validity = validFLa4aFit
)
#?setValidity("FLa4aFit", validFLa4aFit)
#invisible(createFLAccesors(new("FLa4aFit")))   # }}}
#mcf - make compatiple flq

