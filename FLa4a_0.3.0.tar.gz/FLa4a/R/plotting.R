
#' adds bubbles to a plot
#'
#'
#' @param x the x location of the bubbles
#' @param y the y location of the bubbles
#' @param v a vector of bubble sizes
#' @param scale a scaling factor 
#' @param ...  extra arguments to plot and points
#' @return a pointer to the environment in which summaries of the data reside
#' @note \code{extractData} is intended to be used internally
#' @author anders nielson \email{an@@dtu.aqua.dk}
bp <- function(x, y, v, scale = 3, ...)
{
  plot(x, y, cex = sqrt(abs(v)) * scale, col = ifelse(v<0,'tomato2','blue'), 
       pch = ifelse(v < 0, 16, 1), ...)
  points(x[v>0], y[v>0], cex = sqrt(v[v>0]) * scale, col='blue', pch=1, ...)
}


#' Extracts the catch and survey data, makes useful summaries
#' and places them in an environment
#'
#'
#' @param stock an FLStock object containing catch and stock information
#' @param index an FLIndex object containing survey indices 
#' @return a pointer to the environment in which summaries of the data reside
#' @note \code{extractData} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
matrix.plot <- 
function (x, 
          xlim = 0.5 + c(0, di[2]), 
          ylim = 0.5 + c(di[1], 0),
          xlab = "", ylab = "", 
          cols = c("red","blue")) 
{

  df <- data.frame(i = c(row(x)), j = c(col(x)), x = c(x))

  di <- dim(x)
  xx <- df $ x
  rx <- range(xx, finite = TRUE)
  nn <- 100
  n0 <- min(nn, max(0, round((0 - rx[1])/(rx[2] - rx[1]) * nn)))
  levelplot(
    df$x ~ df$j + df$i,
    sub = "", xlab = xlab, ylab = ylab, xlim = xlim, ylim = ylim, 
    aspect = "iso", colorkey = FALSE, 
    col.regions = colorRampPalette(rev(cols))(16), cuts = 15, 
    par.settings = list(background = list(col = "transparent")), 
    panel = function(x, y, z, subscripts, at, ..., col.regions) 
      {
        x <- as.numeric(x)
        y <- as.numeric(y)
        numcol <- length(at) - 1
        num.r <- length(col.regions)
        col.regions <- if (num.r <= numcol) {
          rep(col.regions, length = numcol)
        } else {
          col.regions[1 + ((1:numcol - 1) * (num.r - 1))%/%(numcol - 1)]
        }
        zcol <- rep.int(NA_integer_, length(z))
        for (i in seq_along(col.regions)) {
          zcol[!is.na(x) &  !is.na(y) & !is.na(z) & at[i] <= z & z < at[i + 1]] <- i
        }
        zcol <- zcol
        wh <- grid::current.viewport()[c("width", "height")]
        wh <- c(grid::convertWidth(wh$width, "inches", valueOnly = TRUE), grid::convertHeight(wh$height, "inches", valueOnly = TRUE)) * par("cra")/par("cin")
        pSize <- wh/di
        pA <- prod(pSize)
        p1 <- min(pSize)
        lwd <- if (p1 < 2 || pA < 6)  0.01 else if (p1 >= 4) 1 else if (p1 > 3)  0.5 else 0.2
        grid.rect(x = x, y = y, width = 1, height = 1, default.units = "native", gp = gpar(fill = col.regions[zcol],  lwd = lwd, col = if (lwd < 0.01) NA))
     }
  )
}

#' Extracts the catch and survey data, makes useful summaries
#' and places them in an environment
#'
#'
#' @param stock an FLStock object containing catch and stock information
#' @param index an FLIndex object containing survey indices 
#' @return a pointer to the environment in which summaries of the data reside
#' @note \code{extractData} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
  panel.3d.levelplot <-
  function(x, y, z, rot.mat, distance, zlim.scaled, at, drape = TRUE, shade = FALSE, cols, ...) 
  {
    zrng <- 0.001 * diff(zlim.scaled) 
    ## vertical range of 2nd surface (>0)     
    z.scaled <- (z - min(z))/diff(range(z))     
    at.scaled <- (at - min(z))/diff(range(z)) 
    new.level <- zlim.scaled[2]    
    new.z <- new.level + zrng * (z.scaled)     
    new.at <- new.level + zrng * (at.scaled)     
    panel.3dwire(x, y, new.z, at = new.at,
                 col = grey(.9),
                 rot.mat = rot.mat, distance = distance,
                 shade = FALSE,
                 drape = TRUE,
                 zlim.scaled = zlim.scaled,
                 alpha = 1, ...)
    dots <- list(...)
    dots $ col.regions <- paste0(colorRampPalette(rev(cols))(100), "AA")
    dots $ background <- "transparent"
    args <- c(dots, list(x=x, y=y, z=z, rot.mat = rot.mat, distance = distance,
                 zlim.scaled = zlim.scaled, at = at, drape = FALSE, shade = FALSE))
    do.call(panel.3dwire, args)
  }

#' Extracts the catch and survey data, makes useful summaries
#' and places them in an environment
#'
#'
#' @param stock an FLStock object containing catch and stock information
#' @param index an FLIndex object containing survey indices 
#' @return a pointer to the environment in which summaries of the data reside
#' @note \code{extractData} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
  plotError <- function(x, y, y.se, FUN = function(x) x, ylab="", xlab="", add = FALSE, cols) {
    ylim <- c(0, FUN(max(y + 2*y.se)))
    if (!add) plot(x, FUN(y), ylab=ylab, xlab=xlab, type='n', ylim = ylim, las=1) 
    polygon(c(x, rev(x)), FUN(c(y - 2.58*y.se, rev(y + 2.58*y.se))), border=FALSE, col=cols[1], density=NA) 
    polygon(c(x, rev(x)), FUN(c(y - 1.96*y.se, rev(y + 1.96*y.se))), border=FALSE, col=cols[2], density=NA)
    polygon(c(x, rev(x)), FUN(c(y - .675*y.se, rev(y + .675*y.se))), border=FALSE, col=cols[3], density=NA)
    lines(x, FUN(y), lwd=2)
  }

