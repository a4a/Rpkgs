# FLa4aFit-class - «Short one line description»
# FLa4aFit-class

## FLa4aFit             {{{
validFLa4aFit <- function(object){

        # All FLQuant objects must have same dimensions
        Dim <- dim(object@stock.n)
        if (!all(dim(object@harvest) == Dim))
                return("stock.n and harvest arrays must have same dimensions")

        # Everything is fine
        return(TRUE)
}
#' FLa4aFit extends \code{"FLAssess"} class.
#'
#' Some details about this class and my plans for it in the body.
#'
#' \describe{
#'    \item{myslot1}{A logical keeping track of something.}
#'
#'    \item{myslot2}{An integer specifying something else.}
#' 
#'    \item{myslot3}{A data.frame holding some data.}
#'  }
#' @name FLa4aFit-class
#' @rdname FLa4aFit-class
#' @exportClass FLa4aFit
setClass("FLa4aFit",
        representation(
                "FLAssess",
                stock.n      = "FLQuant",
                harvest      = "FLQuant",
                catch.n      = "FLQuant",
                index.name   = "character",
                index.range  = "list",
                index        = "FLQuants",                                
                catch.lres   = "FLQuant",
                catch.lhat   = "FLQuant",
                catch.lvar   = "FLQuant",                
                index.lres   = "FLQuants",
                index.lhat   = "FLQuants",
                index.lvar   = "FLQuants",
                logq         = "FLQuants",
                call         = "character",
                fit.sum      = "numeric",
                coefficients = "numeric",
                covariance   = "matrix",
                models       = "list"),
        prototype = prototype(
                stock.n      = new('FLQuant'),
                harvest      = new('FLQuant'),
                catch.n      = new('FLQuant'),
                index.name   = new('character'),
                index.range  = new('list'),
                index        = new('FLQuants'),                                
                catch.lres   = new('FLQuant'),
                catch.lhat   = new('FLQuant'),
                catch.lvar   = new('FLQuant'),                
                index.lres   = new('FLQuants'),
                index.lhat   = new('FLQuants'),
                index.lvar   = new('FLQuants'),
                logq         = new('FLQuants'),
                call         = "new(\"FLa4aFit\")",
                fit.sum      = new('numeric'),
                coefficients = new('numeric'),
                covariance   = new('matrix'),
                models       = new('list')),
        validity = validFLa4aFit
)
#?setValidity("FLa4aFit", validFLa4aFit)
#invisible(createFLAccesors(new("FLa4aFit")))   # }}}
#mcf - make compatiple flq

