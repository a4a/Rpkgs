

#' A collection of example settings for the ple4 data set
#'
#'
#' @param example the example number
#' @return a list of arguments to be passed to the fitting function
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
getExampleSettings <- function(example)
{

if (example == 0) {

  # seperable F model:
  #   - fishery selection flat from age 7 
  #   - mortality level varies through time according to a 
  #     thin plate spline wth 3 degreed of freedom

  fmodel <-       ~ factor(age1to7) + s(year, k=3)
  fmodel.extra <- list(age1to7 = expression( replace(age, age>7, 7)))

  # Q model:
  #   - seperate catchability for each age flat from age 6 
  qmodel <- list( ~ factor(age1to6), 
                  ~ factor(age1to6))
  qmodel.extra <- list(age1to6 = expression( replace(age, age>6, 6)))

  # R model:
  #   - seperate recruitements estimated for each year
  rmodel <-       ~ factor(year)

} else if (example == 1) {

  # 2D smooth for fishing mortality (tensor product of 2 thin plate splines):
  #   - fishery selection given by a thin plate spline with 4 DF 
  #   - mortality level varies through time according to a 
  #     thin plate spline wth 3 degreed of freedom.
  #   - selectivity pattern can evolve

  fmodel <-       ~ te(age, year, k = c(4,20))

  # Q model: 
  #   - catchability pattern (tps with 3 df) for each year
  #   - fixed after 2003

  qmodel <- list( ~ s(age, by = factor(firstyears), k = 3), 
                  ~ s(age, by = factor(firstyears), k = 3))
  qmodel.extra <- list(firstyears = expression(replace(year, year>2003, 2003)))

  # R model:
  #   - seperate recruitements estimated for each year

  rmodel <-       ~ factor(year)

} else 
if (example == 2) {

  fmodel <-       ~ s(age, k = 20, by = factor(age1to7)) + s(age, k = 4) + age1
  fmodel.extra <- list(age1to7 = expression( replace(age, age>7, 7) ),
                       age1    = expression( as.numeric(age==1)     ))
                      
  qmodel <- list( ~ te(age, firstyears, k = c(3, 5)), 
                  ~ te(age, firstyears, k = c(3, 5)))
  qmodel.extra <- list(firstyears = expression(replace(year, year>2003, 2003)))

  rmodel <-       ~ factor(year)

} else
if (example == 3) {

  fmodel <- ~ bs(age, 4) + factor(year)

  qmodel <- list( ~ s(age, k=3), 
                  ~ s(age, k=3))

  rmodel <-       ~ factor(year)
} else
if (example == 4) {

  fmodel <- ~ bs(age, 4) + factor(year)

  qmodel <- list( ~ s(age, k=4), 
                  ~ s(age, k=4) )

  qprior <- c("iid","iid")
  qtau <- c(0.05, 0.05)

  rmodel <-       ~ factor(year)
} else
if (example == 5) {

  fmodel <- ~ s(age, k=4) + s(year, k=10)
  fprior <- "iid"
  ftau <- 0.01

  qmodel <- list( ~ s(age, k=4), 
                  ~ s(age, k=4) )

  rmodel <-       ~ factor(year)
} else
if (example == 6) {

  fmodel <- ~ s(year, k = 5, by = age1) + s(year, k = 5, by = age2)
  fmodel.extra <- list(age1 = expression(as.numeric(age==1)),
                       age2 = expression(as.numeric(age==2)))  
  fprior <- "rw2"
  ftau <- 0.01

  qmodel <- list( ~ s(age, k=4), 
                  ~ s(age, k=4) )

  rmodel <-       ~ factor(year)
} else
if (example == 7) {

  fmodel <- ~ s(year, k = 5, by = age1) + s(year, k = 5, by = age2)
  fmodel.extra <- list(age1 = expression(as.numeric(age==1)),
                       age2 = expression(as.numeric(age==2)))  
  fprior <- "rw2"
  ftau <- 0.01

  qmodel <- list( ~ te(age, year, k=c(4,7)), 
                  ~ te(age, year, k=c(4,4)))

  rmodel <-       ~ factor(year)
} else
if (example == 8) {

  fmodel <- ~ s(year, k = 5, by = age1) + s(year, k = 5, by = age2)
  fmodel.extra <- list(age1 = expression(as.numeric(age==1)),
                       age2 = expression(as.numeric(age==2)))  
  fprior <- "rw2"
  ftau <- 0.01

  qmodel <- list( ~ te(age, year, k=c(4,4)), 
                  ~ te(age, year, k=c(4,3)))
  qprior <- c("iid","iid")
  qtau <- c(0.03, 0.03)

  rmodel <-       ~ factor(year)
}
rm(example)

  as.list(environment())
}


