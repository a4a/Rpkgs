#====================================================================
# tests for sca
#====================================================================
library(FLa4a)
data(ple4)
data(ple4.indices)
data(ple4.index)

#====================================================================
# run sca
#====================================================================
fit0 <-  a4aSCA(ple4, FLIndices(ple4.index))

#====================================================================
# bevholt
#====================================================================
fitbh <-  a4aSCA(ple4, FLIndices(ple4.index), srmodel=~bevholt(CV=0.1))

fitbhsv <-  a4aSCA(ple4, FLIndices(ple4.index), srmodel=~bevholtSV(CV=0.1), useADMB = TRUE)

#====================================================================
# ricker
#====================================================================

fitr <-  a4aSCA(ple4, FLIndices(ple4.index), srmodel=~ricker(CV=0.1))

#====================================================================
# hockey-stick
#====================================================================

fith <-  a4aSCA(ple4, FLIndices(ple4.index), srmodel=~hockey(CV=0.1))

#====================================================================
# geomean
#====================================================================

fitg <-  a4aSCA(ple4, FLIndices(ple4.index), srmodel=~geomean(CV=0.1))

#====================================================================
# mean
#====================================================================

fitm <-  a4aSCA(ple4, FLIndices(ple4.index), srmodel=~1)

stk <- expand(ple4, age=0:10)
catch.n(stk)["0"] <- rlnorm(catch.n(stk)["0"])
catch.wt(stk)["0"] <- catch.wt(stk)["1"]
stock.wt(stk)["0"] <- stock.wt(stk)["1"]
m(stk)["0"] <- m(stk)["1"]
m.spwn(stk)["0"] <- m.spwn(stk)["1"]
harvest.spwn(stk)["0"] <- harvest.spwn(stk)["1"]
mat(stk)["0"] <- mat(stk)["1"]
stk <- setPlusGroup(stk, 10)
fit00 <-  a4aSCA(stk, FLIndices(ple4.index))

#====================================================================
# bevholt
#====================================================================
fitbh <-  a4aSCA(stk, FLIndices(ple4.index), srmodel=~bevholt(CV=0.1))

fitbhsv <-  a4aSCA(ple4, FLIndices(ple4.index), srmodel=~bevholtSV(CV=0.1), useADMB = TRUE)

#====================================================================
# ricker
#====================================================================

fitr <-  a4aSCA(ple4, FLIndices(ple4.index), srmodel=~ricker(CV=0.1))

#====================================================================
# hockey-stick
#====================================================================

fith <-  a4aSCA(ple4, FLIndices(ple4.index), srmodel=~hockey(CV=0.1))

#====================================================================
# geomean
#====================================================================

fitg <-  a4aSCA(ple4, FLIndices(ple4.index), srmodel=~geomean(CV=0.1))

#====================================================================
# mean
#====================================================================

fitm <-  a4aSCA(ple4, FLIndices(ple4.index), srmodel=~1)


