


#' Adds the location of the a4a executable to the search path.  This function is called when FLa4a is attached
#'
#'
#' @param libname required
#' @param pkgname required
#' @return a pointer to the environment in which summaries of the data reside
#' @note \code{.onAttach} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
bevholt <- function(formula, ...) {
  model.frame(formula, ...)
}






#' Adds the location of the a4a executable to the search path.  This function is called when FLa4a is attached
#'
#'
#' @param libname required
#' @param pkgname required
#' @return a pointer to the environment in which summaries of the data reside
#' @note \code{.onAttach} is intended to be used internally
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
.onAttach <- function(libname, pkgname)
{
  ## TODO find out sep char for environment vars on macs
  sep <- if (os.type("linux")) ":" else if (os.type("windows")) ";" else ","
  path <- paste0(a4a.dir(), sep, Sys.getenv("PATH"))
  Sys.setenv(PATH=path)
}




#' paste without seperation for bacl compatibility
#'
#'
#' @param stock an FLStock object containing catch and stock information
#' @param index an FLIndex object containing survey indices 
#' @return a pointer to the environment in which summaries of the data reside
#' @note \code{a4a.dir} is intended to be used internally and based on the same function in INLA
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
paste0 <- function (..., collapse = NULL) {
  paste(..., sep = "", collapse = collapse)
}


#' returns the location on the file system of the ADMB executable
#'
#'
#' @param stock an FLStock object containing catch and stock information
#' @param index an FLIndex object containing survey indices 
#' @return a pointer to the environment in which summaries of the data reside
#' @note \code{a4a.dir} is intended to be used internally and based on the same function in INLA
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
a4a.dir <- function () 
{
  if (os.type("mac")) {
    fnm <- system.file(paste("bin/mac/", os.32or64bit(), "bit", sep = ""), package = "FLa4a")
  }
  else if (os.type("linux")) {
    fnm <- system.file("bin/linux", package = "FLa4a")
  }
  else if (os.type("windows")) {
    fnm <- system.file("bin/windows", package = "FLa4a")
  }
  else {
    stop("Unknown OS")
  }
  if (file.exists(fnm)) {
    return(fnm)
  }
  else {
    stop(paste("FLa4a installation error; no such file", fnm))
  }
}


#' returns TRUE if correct operating system is passed as an argument
#'
#'
#' @param type character string of operating system type
#' @return logical
#' @note \code{os.type} is intended to be used internally and based on the same function in INLA
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
os.type <- function (type = c("linux", "mac", "windows", "else")) 
{
  type = match.arg(type)
  if (type == "windows") {
    return(.Platform$OS.type == "windows")
  }
  else if (type == "mac") {
   result = (file.info("/Library")$isdir && file.info("/Applications")$isdir)
    if (is.na(result)) {
      result = FALSE
    }
    return(result)
  }
  else if (type == "linux") {
    return((.Platform$OS.type == "unix") && !os.type("mac"))
  }
  else if (type == "else") {
    return(TRUE)
  }
  else {
    stop("This shouldn't happen.")
  }
}


#' finds the size of the operating system addresses
#'
#' @return a character giving the size of the operating system address bus
#' @note \code{extractData} is intended to be used internally and based on the same function in INLA
#' @author Colin Millar \email{colin.millar@@jrc.ec.europa.eu}
os.32or64bit <- function () 
{
  return(ifelse(.Machine$sizeof.pointer == 4, "32", "64"))
}



