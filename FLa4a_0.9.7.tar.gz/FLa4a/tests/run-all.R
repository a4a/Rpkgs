library(testthat)
library(FLa4a)

test_package("FLa4a")
