
- CHANGED FLmp to FLmse
- ADDED mp.R: mp()
- ADDED dispatch.R: flsval(), flival(), flpval(), flfval(), flqval()
- RENAMED a4ampDispatch() to mpDispatch()
- ADDED oem.R: sampling.eom(), RENAMED perfect.oem()
- ADDED sa.R: perfect.sa()
- ADDED hcr.R: ices.hcr(), RENAMED fixedF.hcr(), RENAMED movingF.hcr()
- ADDED iem.R: noise.iem()
- ADDED is.R: tac.is(), effort.is()
- ADDED tm.R: map.tm()
- ADDED phcr.R: RENAMED movingF.hcr()

- @FLXSA, ADDED xsa.sa

# TODO

- FIX noise.iem for FLasher: functions that change fwdControl defined in FLash/FLasher?
- MOVE FLRP to FLBRP
- @FLAssess, ADD vpa.sa
