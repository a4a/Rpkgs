# mse 0.9

## USER-VISIBLE CHANGES

- Complete new code base.

## BUG FIXES

## UTILITIES

## DOCUMENTATION

## DEPRECATED & DEFUNCT

# mse 0.0.4

## USER-VISIBLE CHANGES

- Methods moved to FLCore: rnoise, rlnoise
